 This project demonstrates how to create interact with a Azure Open AI using
	 -ChatModel class or ( see ChatModelController.java &ChatModelConfig)
	 -ChatClient class (via Fluent API)
 
  ChatClient can be created  in 2 ways
 1) programmatically configured ChatClient (see ChatClientController.java)
 3) directly using ChatModel implementation class -AzureOpenAIChatClient (see ChatModelController.java)
 
 
 Dependencies
 -----------------------
 In pom.xml see below dependencies
 
 <dependency>
			<groupId>org.springframework.ai</groupId>
			<artifactId>spring-ai-starter-model-azure-openai</artifactId>
		</dependency>			
		<dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-starter-web</artifactId>
		</dependency>
		<dependency>
	  <groupId>org.springframework.boot</groupId>
	  <artifactId>spring-boot-starter-webflux</artifactId>
	</dependency>
	
In application.properties
-------------------------------------------
In application.properties
-------------------------------------------

IMPORTANT: Please replace the properties below with your own LLM provider details.

See below properties for Azure Open AI

		# API key for authentication with the chat model provider . Add to environment variables in run config
		spring.ai.azure.openai.api-key=${AZURE_API_KEY}
		# Endpoint URL for the chat model's API
		spring.ai.azure.openai.endpoint=https://java-ai-resgrp.openai.azure.com/
		#deployment model or chat model name
		spring.ai.azure.openai.chat.options.model=gpt-4o
	
Replace with Vertex AI Gemini properties similar to below as per your project details if needed

spring.ai.vertex.ai.gemini.project-id=${PROJECT_ID}
spring.ai.vertex.ai.gemini.location=us-central1
spring.ai.openai.chat.base-url=https://generativelanguage.googleapis.com
spring.ai.openai.chat.completions-path=/v1beta/openai/chat/completions
spring.ai.openai.api-key=${GEMINI_API_KEY}
spring.ai.openai.chat.options.model=gemini-2.0-flash-001
	
	
Right click on project->Run->Run Configurations->Environment Variables and set the AZURE_API_KEY variable to your Azure OpenAI API key.

Where to get Azure Open AI API key
---------------------------------------------------
1. Go to https://portal.azure.com/
2. Create a new resource group if you don't have one.
3. Create a new Azure OpenAI resource in the resource group.
4. Once the resource is created, go to the resource and find the "Keys and Endpoint" section.
5. Copy the API key and endpoint URL.
		 