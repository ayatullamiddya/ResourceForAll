package com.ltt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo1ChatclientapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Demo1ChatclientapiApplication.class, args);
	}

}
