package com.ltt.chatmodel;

import org.springframework.ai.azure.openai.AzureOpenAiChatModel;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ChatModelConfig {

    @Bean
    public ChatClient openAiChatClient(AzureOpenAiChatModel chatModel) {
        return ChatClient.create(chatModel);
    }
 
    
    

  
}