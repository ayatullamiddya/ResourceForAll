package com.ltt.chatmodel;

import java.util.Map;

import org.springframework.ai.azure.openai.AzureOpenAiChatModel;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import reactor.core.publisher.Flux;

/**
 * This class demonstrates how  the ChatModel or its implementing Classes can be used
 * directly to call the AI model.
 * See how to use call() and stream() methods and return String, Map, ChatResponse objects
 */
@RestController
public class ChatModelController {

	@Autowired //configured via Config class
    private  AzureOpenAiChatModel chatModel;	 
	
	 @GetMapping("/ai/jokechat2")
	    public String jokeString(@RequestParam(value = "message", defaultValue = "Tell me a joke") String message) {
	        return chatModel.call(message);
	    }
	 
	 /**
	     * This method uses the call(Prompt) overloaded method with Prompt obj to call AI model
	     * @return single ChatResponse  object
	     */
	    @GetMapping("/ai/jokechat3")
	    public ChatResponse jokeChatResponse() {
	        return chatModel.call(new Prompt("Tell me a joke"));
	    }
	    
	    /**
	     * This method uses the stream(Prompt) overloaded method with Prompt obj to call AI model
	     * @return asynchronous streaming response in the form of Flux object
	     */
	    @GetMapping("/ai/jokechat4")
		public Flux<ChatResponse> generateStream() {
	        Prompt prompt = new Prompt(new UserMessage("Tell me a 7 jokes"));
	        return chatModel.stream(prompt);
	    }
   /**
    * This method uses the call(String) method to call AI model
    * @param message from request - url http://localhost:8080/ai/jokechat?message="tell me a joke"
    * @return single synchronous response as map with key name result and value as joke value from ai model (like json)
    */
    @GetMapping("/ai/jokechat")
    public Map<String,String> jokeJson(@RequestParam(value = "message", defaultValue = "Tell me a joke") String message) {
        return Map.of("result", chatModel.call(message));
    }

    
   
}