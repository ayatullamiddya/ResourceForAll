package com.ltt.chatmodel;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyEmitter;

import reactor.core.publisher.Flux; 

/**
 * This class contains a generic ChatClient reference that can be used to 
 * auto-wire chatclient which has already been created at startup.
 */
@RestController
public class ChatClientController {

	@Autowired
	private ChatClient chatClient;

	//Url to test : http://localhost:8080/ai/onejoke
	@GetMapping("/ai/onejoke")
    public String joke() {
        return this.chatClient.prompt()
            .user("Tell me a joke.")
            .call()
            .content();
    }
	
	
	@GetMapping("/ai/systemjoke")
    public String joke2() {
        return this.chatClient.prompt()
        	.system("You are a funny AI assistant who talks only about animals.")
            .user("Tell me a joke.")
            .call()
            .content();
    }
	
	//Url to test : http://localhost:8080/ai/streamjoke
    @GetMapping("/ai/streamjoke")
    public ResponseBodyEmitter streamJoke() {
        ResponseBodyEmitter emitter = new ResponseBodyEmitter();
        Flux<String> flux = chatClient.prompt().user("how to joke").stream().content();

        flux.subscribe(
            chunk -> {
                try {
                    emitter.send(chunk);
                } catch (Exception e) {
                    emitter.completeWithError(e);
                }
            },
            emitter::completeWithError,
            emitter::complete
        );
        return emitter;
    }

  
    
    
    
    
    
    
}

/**
ResponseBodyEmitter emitter = new ResponseBodyEmitter();: Creates an emitter to send data to the client asynchronously.
	•  Flux<String> flux = ...: Gets a reactive stream (Flux<String>) of joke responses from the AI chat client.
	•  flux.subscribe(...): Subscribes to the stream, sending each chunk to the client via the emitter.
	•  On each chunk, emitter.send(chunk) sends the data.
	•  On error, emitter.completeWithError(e) completes with error.
	•  On completion, emitter.complete() signals the end of the stream.
	•  return emitter;: Returns the emitter to the client, enabling real-time streaming of responses.
*/