package com.ltt.multiapi;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.openai.OpenAiChatModel;
import org.springframework.ai.openai.OpenAiChatOptions;
import org.springframework.ai.openai.api.OpenAiApi;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * This class shows how at runtime you can switch between different models.
 * Both gemini and Azure OpenAI models are used in this example.
 * the mutate() method is used to create a new instance of the model with the specified options.
 */
@Service
public class MultiModelService {

	@Autowired
	private OpenAiChatModel baseChatModel;

	@Autowired
	private OpenAiApi baseOpenAiApi;

	//Below values are injected from application.properties or application.yml
	 @Value("${gemini.api.key}") String geminiApiKey;
	 @Value("${azure.api.key}") String azureApiKey;
	 @Value("${gemini.api.url}") String geminiUrl;
     @Value("${gemini.api.completions.path}") String completionsPath;
     @Value("${spring.ai.azure.openai.endpoint}") String azureUrl;
     @Value("${azure.completions.path}") String azureCompletionsPath;
     
	public String getModelResponse(String modelName) {
		try {
			//Setup Azure and Gemini APIs with their respective URLs and API keys
			OpenAiApi geminiApi = baseOpenAiApi.mutate().baseUrl(geminiUrl)
					  .completionsPath(completionsPath).apiKey(System.getenv("GEMINI_API_KEY")).build();

			
			OpenAiApi azureopenAi = baseOpenAiApi.mutate().baseUrl(azureUrl).completionsPath(azureCompletionsPath)
					.apiKey(System.getenv("AZURE_API_KEY")).build();

			//Create new instances by switching from the baseModel
			OpenAiChatModel geminiChatModel = baseChatModel.mutate().openAiApi(geminiApi)
					.defaultOptions(OpenAiChatOptions.builder().model("gemini-2.0-flash-001").temperature(0.5).build())
					.build();

			
			OpenAiChatModel azureopenAiChatModel = baseChatModel.mutate().openAiApi(azureopenAi)
					.defaultOptions(OpenAiChatOptions.builder().model("gpt-4o").temperature(0.7).build()).build();
			
			// Simple prompt for both models
			String prompt = "What is the capital of France?";
			
			//Dynamic switch at runtime -If userinput is gemini, use the geminiChatModel, else use azureopenAiChatModel
			ChatModel model = modelName.equalsIgnoreCase("gemini") ? geminiChatModel : azureopenAiChatModel;
			
			//Call the chat client
			String response = ChatClient.builder(model).build().prompt(prompt).call().content();
			return response;

		} catch (Exception e) {
			System.out.println("Error in getting model response: " + e.getMessage());
			e.printStackTrace();
			return "error";
		}
	}
}