package com.ltt.multi;

import org.springframework.ai.azure.openai.AzureOpenAiChatModel;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.openai.OpenAiChatModel;
import org.springframework.ai.openai.api.OpenAiApi;
import org.springframework.ai.vertexai.gemini.VertexAiGeminiChatModel;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * This configuration class defines two ChatClient beans, one for Azure OpenAI and one for Vertex AI Gemini.
 * The beans are created using the respective chat models injected by Spring, with properties defined in application.properties.
 * They will be used in used in JokeController.java
 **/
@Configuration
public class ChatClientConfigTwo {
	
	//ChatClient created with Azure OpenAI chat model injected
	//by Spring using properties in application.properties
    @Bean("azure")
    public ChatClient openAiChatClient(AzureOpenAiChatModel chatModel) {
        return ChatClient.create(chatModel);
    }

    //ChatClient created with Vertex AI chat model
	//by Spring using properties in application.properties
    @Bean("gemini")
    public ChatClient geminiChatClient(VertexAiGeminiChatModel chatModel) {
        return ChatClient.create(chatModel);
    }
    
    
    
    
   
	
}