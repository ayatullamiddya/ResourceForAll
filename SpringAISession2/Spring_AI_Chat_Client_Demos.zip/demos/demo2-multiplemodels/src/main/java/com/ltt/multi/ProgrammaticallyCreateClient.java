package com.ltt.multi;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.vertexai.gemini.VertexAiGeminiChatModel;
import org.springframework.ai.vertexai.gemini.VertexAiGeminiChatOptions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.cloud.vertexai.Transport;
import com.google.cloud.vertexai.VertexAI;

/**
 * This class demonstrates how you can create a chatclient programatically using
 * code without relying on Spring properties. Values here are loaded from environment
 * variables.
 * 
 */
@RestController
public class ProgrammaticallyCreateClient {
	
	private VertexAI vertexAI;
	
	ChatClient genericChatClient; 
	
	public ProgrammaticallyCreateClient() {
		String projectId = System.getenv("PROJECT_ID");
        String location = System.getenv("LOCATION");
        
		// Create a VertexAI instance
		vertexAI = new VertexAI.Builder()
			    .setProjectId(projectId)
			    .setLocation(location)
			    .setTransport(Transport.GRPC)
			    .build();

			// Create the chat model with custom configuration
			VertexAiGeminiChatModel chatModel = VertexAiGeminiChatModel.builder()
			    .vertexAI(vertexAI)
			    .defaultOptions(VertexAiGeminiChatOptions.builder()
			        .model("gemini-2.0-flash-001")			       
			        .build())			    
			    .retryTemplate(RetryTemplate.builder().build())
			    .build();
			
			genericChatClient =ChatClient.create(chatModel);
	}
	
	@GetMapping("/joke")
	String simpleAzureJoke() {
		return genericChatClient.prompt("Tell me a joke").call().content();
		
	}
}
