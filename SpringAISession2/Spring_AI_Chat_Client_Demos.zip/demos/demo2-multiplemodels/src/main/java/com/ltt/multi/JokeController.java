package com.ltt.multi;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ltt.multiapi.MultiModelService;

/**
 * Beans configured in ChatClientConfigTwo.java are injected here.
 * A generic chatclient can be created or an LLM specific one can be used.
 */
@RestController
public class JokeController {

	@Qualifier("azure")
	@Autowired
	ChatClient azureAiChatClient;

	@Qualifier("gemini")
	@Autowired
	ChatClient geminiChatClient;

	//@Qualifier("gemini")
	@Qualifier("gemini")
	@Autowired
	ChatClient genericChatClient; //generic chat client that can be used for any model


	//this method uses the generic chat client to get a joke.
	// Url to test : http://localhost:8080/ai/joke
	@GetMapping("/anymodel/joke")
	String simpleJoke() {
		return this.genericChatClient.prompt("Tell me a joke").call().content();
	}
	
	@GetMapping("/azureai/joke")
	String simpleAzureJoke() {
		return this.azureAiChatClient.prompt("Tell me a joke").call().content();
		
	}
	
	@GetMapping("/geminiai/joke")
	String simpleGeminiJoke() {
		return this.geminiChatClient.prompt("Tell me a joke").call().content();
		
	}
	
	
	
}