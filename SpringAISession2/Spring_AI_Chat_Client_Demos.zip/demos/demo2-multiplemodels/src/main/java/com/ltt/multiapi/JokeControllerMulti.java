package com.ltt.multiapi;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class JokeControllerMulti {
	@Autowired
	MultiModelService multiModelService;
	
	@GetMapping("/azure/joke")
		String simpleAzureJoke() {
			
			return multiModelService.getModelResponse("azure");
		}
		
		@GetMapping("/gemini/joke")
		String simpleGeminiJoke() {
		
			return multiModelService.getModelResponse("gemini");
		}
}

