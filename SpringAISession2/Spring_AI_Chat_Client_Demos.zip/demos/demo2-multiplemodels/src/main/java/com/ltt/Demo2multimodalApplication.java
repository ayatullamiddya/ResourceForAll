package com.ltt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo2multimodalApplication {

	public static void main(String[] args) {
		SpringApplication.run(Demo2multimodalApplication.class, args);
	}

}
