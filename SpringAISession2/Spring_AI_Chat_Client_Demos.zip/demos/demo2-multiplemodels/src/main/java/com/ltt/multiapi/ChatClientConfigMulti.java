package com.ltt.multiapi;

import org.springframework.ai.azure.openai.AzureOpenAiChatModel;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.openai.OpenAiChatModel;
import org.springframework.ai.openai.api.OpenAiApi;
import org.springframework.ai.vertexai.gemini.VertexAiGeminiChatModel;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * This configuration class defines a base ChatClient bean that used Azure OpenAI LLM.
 * The bean is created using the generic OpenAiChatModel  and OpenAPi classes 
 * This LLM will be dynamically switched in JokeControllerMulti.java
 **/
@Configuration
public class ChatClientConfigMulti {
	
	@Value("${AZURE_API_KEY}")
	String api_key;

    //Set up the OpenAI API rest client with the Azure OpenAI endpoint   
    @Bean
    public OpenAiApi chatCompletionApi() {
        return OpenAiApi.builder().baseUrl("https://java-ai-resgrp.openai.azure.com").apiKey(api_key).build();
    }

    //Build the generic OpenAiChatModel with the OpenAiApi
    @Bean
    public OpenAiChatModel openAiClient(OpenAiApi openAiApi) {
        return OpenAiChatModel.builder()
                .openAiApi(openAiApi)
                .build();
    }
	
}