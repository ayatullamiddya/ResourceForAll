package com.ltt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo2multimodalApplicationTests {

	@Test
	void contextLoads() {
	}

}
