This project demonstrates how to use multiple ChatModels within the same application 
and switch between them dynamically based on user input.

package com.ltt.multi 
------------------------
ChatClient objects are being created programmtically as spring beans.

Observe the following classes:
-ChatClientConfigTwo.java 
	- generic and LLM specific chat client beans created here
-JokeController.java 	
	- a generic chat client bean can be used to call the LLM (loose coupling)
		OR a specific chat client can be used to call the LLM (tight coupling). Using @Qualifier
		annotation we can switch between the two.
		Hit the method rest endpoint urls to see the outcome.
		
In package com.ltt.multiapi
---------------------------
Multiple ChatClient objects are being created programmatically as spring beans.
and dynamically switched based on user input.

-ChatClientConfigMulti.java
    - generic and LLM specific chat client beans created here
		

-------------------------------------------
In application.properties
-------------------------------------------

IMPORTANT: Please replace the properties below with your own LLM provider details.

See below properties for Azure Open AI

		# API key for authentication with the chat model provider . Add to environment variables in run config
		spring.ai.azure.openai.api-key=${AZURE_API_KEY}
		# Endpoint URL for the chat model's API
		spring.ai.azure.openai.endpoint=https://java-ai-resgrp.openai.azure.com/
		#deployment model or chat model name
		spring.ai.azure.openai.chat.options.model=gpt-4o
	
Replace with Vertex AI Gemini properties similar to below as per your project details if needed

spring.ai.vertex.ai.gemini.project-id=${PROJECT_ID}
spring.ai.vertex.ai.gemini.location=us-central1
spring.ai.openai.chat.base-url=https://generativelanguage.googleapis.com
spring.ai.openai.chat.completions-path=/v1beta/openai/chat/completions
spring.ai.openai.api-key=${GEMINI_API_KEY}
spring.ai.openai.chat.options.model=gemini-2.0-flash-001