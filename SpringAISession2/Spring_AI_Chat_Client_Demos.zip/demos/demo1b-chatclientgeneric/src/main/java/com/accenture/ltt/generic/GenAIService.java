package com.accenture.ltt.generic;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.openai.OpenAiChatModel;
import org.springframework.stereotype.Service;

@Service
public class GenAIService {

	//generic ChatClient interface
    private ChatClient client;

    //Create chat client using generic OpenAiChatModel
    //although in application.properties we specify which 
    //OpenAI model implementation will be used
    public GenAIService(OpenAiChatModel client) {
        this.client = ChatClient.create(client);
    }

    public String queryGenAIModel(String prompt) {
        try {
			return client.prompt(prompt)
			        .call()
			        .content();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        return "Error querying AI model";
    }

}