package com.accenture.ltt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo1bChatclientgenericApplication {

	public static void main(String[] args) {
		SpringApplication.run(Demo1bChatclientgenericApplication.class, args);
	}

}
