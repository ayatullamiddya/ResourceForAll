package com.accenture.ltt.generic;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GenAIController {

    @Autowired
    private  GenAIService aiService;

    @RequestMapping("/ai/query")
    public String queryGenAIModel(@RequestParam(value = "prompt", defaultValue = "Tell me a joke") String prompt) {
        return aiService.queryGenAIModel(prompt);
    }
    
    @RequestMapping("/hello")
    public String hello() {
        return "hello";
    }
}