This demo demonstrates how to create a project using a generic Open AI chat client 
with generic spring ai properties and starters in pom.xml.

Open AI LLM has several implmentations like Azure Open AI, Vertex AI Gemini, Amazon Bedrock, etc.
Instead of a vendor specific implementation, this demo uses a generic chat client.


Dependencies
 -----------------------
 In pom.xml see below generic dependencies not LLM specific
 
 		<dependency>
			<groupId>org.springframework.ai</groupId>
			<artifactId>spring-ai-starter-model-openai</artifactId>
		</dependency>
				
	
	
In application.properties
-------------------------------------------
See below generic properties 

		#Note all are generic spring.ai properties not LLM specific ones
spring.ai.openai.api-key=${API_KEY}
spring.ai.openai.chat.base-url=https://generativelanguage.googleapis.com
spring.ai.openai.chat.completions-path=/v1beta/openai/chat/completions
spring.ai.openai.chat.options.model=gemini-2.0-flash-001
	
Note in class GenAIService.java generic OpenAIChatClient is used and similarly generic ChatClient class is used 