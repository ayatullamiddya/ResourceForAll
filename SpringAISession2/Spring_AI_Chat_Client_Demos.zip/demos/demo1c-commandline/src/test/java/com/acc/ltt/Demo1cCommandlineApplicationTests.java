package com.acc.ltt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo1cCommandlineApplicationTests {

	@Test
	void contextLoads() {
	}

}
