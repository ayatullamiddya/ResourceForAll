package com.acc.ltt;

import java.util.Scanner;

import org.springframework.ai.azure.openai.AzureOpenAiChatModel;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.vertexai.gemini.VertexAiGeminiChatModel;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ChatClientExample {
	
	//ChatClient created with Azure OpenAI chat model injected
		//by Spring using properties in application.properties
	    @Bean("azure")
	    public ChatClient openAiChatClient(AzureOpenAiChatModel chatModel) {
	        return ChatClient.create(chatModel);
	    }

	    //ChatClient created with Vertex AI chat model
		//by Spring using properties in application.properties
	    @Bean("gemini")
	    public ChatClient geminiChatClient(VertexAiGeminiChatModel chatModel) {
	        return ChatClient.create(chatModel);
	    }
	    

    @Bean
    CommandLineRunner cli(
            @Qualifier("azure") ChatClient azureChatClient,
            @Qualifier("gemini") ChatClient geminiChatClient) {

        return args -> {
            var scanner = new Scanner(System.in);
            ChatClient chat;

            // Model selection
            System.out.println("\nSelect your AI model:");
            System.out.println("1. Azure OpenAI");
            System.out.println("2. Gemini Open AI");
            System.out.print("Enter your choice (1 or 2): ");

            String choice = scanner.nextLine().trim();

            if (choice.equals("1")) {
                chat = azureChatClient;
                System.out.println("Using Azure model");
            } else {
                chat = geminiChatClient;
                System.out.println("Using Gemini model");
            }

            // Use the selected chat client
            System.out.print("\nEnter your question: ");
            String input = scanner.nextLine();
            String response = chat.prompt(input).call().content();
            System.out.println("ASSISTANT: " + response);

            scanner.close();
        };
    }
}