package com.acc.ltt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo1cCommandlineApplication {

	public static void main(String[] args) {
		SpringApplication.run(Demo1cCommandlineApplication.class, args);
	}

}
