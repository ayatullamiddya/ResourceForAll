This demo demonstrates how to handle response from the Gen AI model.

See class ResponseController.java for the endpoints exposed to handle the response.
See the ResponseService.java class methods that process the response.
Observe the ChatResponse, Generation and ChatResponseMetadata classes that represent the structure of the response from the Gen AI model.

The other classes in the package like ActorsFilms etc are used to store the response data in a structured way.


Dependencies
 -----------------------
 In pom.xml see below dependencies 
 
 <dependency>
			<groupId>org.springframework.ai</groupId>
			<artifactId>spring-ai-starter-model-azure-openai</artifactId>
		</dependency>			
	
	
-------------------------------------------
In application.properties
-------------------------------------------

IMPORTANT: Please replace the properties below with your own LLM provider details.

See below properties for Azure Open AI

		# API key for authentication with the chat model provider . Add to environment variables in run config
		spring.ai.azure.openai.api-key=${AZURE_API_KEY}
		# Endpoint URL for the chat model's API
		spring.ai.azure.openai.endpoint=https://java-ai-resgrp.openai.azure.com/
		#deployment model or chat model name
		spring.ai.azure.openai.chat.options.model=gpt-4o
	
Replace with Vertex AI Gemini properties similar to below as per your project details if needed

spring.ai.vertex.ai.gemini.project-id=${PROJECT_ID}
spring.ai.vertex.ai.gemini.location=us-central1
spring.ai.openai.chat.base-url=https://generativelanguage.googleapis.com
spring.ai.openai.chat.completions-path=/v1beta/openai/chat/completions
spring.ai.openai.api-key=${GEMINI_API_KEY}
spring.ai.openai.chat.options.model=gemini-2.0-flash-001		 