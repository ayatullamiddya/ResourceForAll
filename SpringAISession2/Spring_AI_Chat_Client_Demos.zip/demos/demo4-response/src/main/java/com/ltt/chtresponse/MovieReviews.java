package com.ltt.chtresponse;

record MovieReviews(Movie[] movie_reviews) {
	enum Sentiment {
		POSITIVE, NEUTRAL, NEGATIVE
	}

	record Movie(Sentiment sentiment, String name) {
	}
}