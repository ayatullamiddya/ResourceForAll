package com.ltt.chtresponse;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({"actor", "movies"})
record ActorsFilms(String actor, List<String> movies) {
}