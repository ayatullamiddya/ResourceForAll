package com.ltt.chtresponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ResponseController {
	@Autowired
	public ResponseService service;

	@GetMapping("/response1")
	public String prompt_entityConverters() {
		String output = 
				"Bean/Entity Converters: " + service.response_beanConverter() + "\n\n" +
				"Parameterized Response: " + service.response_parameterized() + "\n\n" +
				"Bean Converter Basic: " + service.response_beanConverter_basic();
		System.out.println("Output: " + output);
		return output;

	}

	@GetMapping("/response2")
	public String prompt_collectionsConverters() {
		String output = "List Output Converter: " + service.response_list() + "\n\n" +
				"Map Output Converter: " + service.response_map() + "\n\n" +
				"List basic Response: " + service.response_list_basic() + "\n\n" +
				"JSON Response: " + service.response_json_basic();
		System.out.println("Output: " + output);
		return output;
	}

	
	
	  @GetMapping("/response3") 
	  public String generation_Demo() { 
		  String output =
	  "Generation Demo: " + service.response_generation_demo();
	  System.out.println("Output: " + output); return output;
	  
	  }
	  
	 
}
