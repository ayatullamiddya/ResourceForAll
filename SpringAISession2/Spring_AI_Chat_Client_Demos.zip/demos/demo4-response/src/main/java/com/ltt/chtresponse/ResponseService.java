package com.ltt.chtresponse;

import java.util.List;
import java.util.Map;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.metadata.ChatResponseMetadata;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.model.Generation;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.chat.prompt.PromptTemplate;
import org.springframework.ai.converter.BeanOutputConverter;
import org.springframework.ai.converter.ListOutputConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.convert.support.DefaultConversionService;
import org.springframework.stereotype.Service;

@Service
public class ResponseService {

	@Autowired
	public ChatClient chatClient;

	@Autowired
	ChatModel chatModel;

	/*
	 * This method demonstrates how to convert the response into 
	 * a bean or entity using the entity() method which internally uses
	 * BeanOutputConverter
	 */
	public ActorsFilms response_beanConverter() {
		ActorsFilms actorsFilms = chatClient.prompt()
				.user(u -> u.text("Generate the filmography of 5 movies for {actor}.").param("actor", "Tom Hanks"))
				.call().entity(ActorsFilms.class);
		return actorsFilms;
	}

	/*
	 * This method demonstrates how to convert the response into 
	 * a Parameterized set of entities using the entity() method
	 */
	public List<ActorsFilms> response_parameterized() {
		List<ActorsFilms> actorsFilmsList = chatClient.prompt()
				.user("Generate the filmography of 5 movies for Tom Hanks and Bill Murray.").call()
				.entity(new ParameterizedTypeReference<List<ActorsFilms>>() {
				});
		return actorsFilmsList;
	}

	/*
	 * This method demonstrates how to convert the response into 
	 * into Parameterized set of entities using the BeanOutputConverter directly
	 * instead of using the entity() method.
	 */
	public List<ActorsFilms> response_beanConverter_basic() {
		BeanOutputConverter<List<ActorsFilms>> outputConverter = new BeanOutputConverter<>(
				new ParameterizedTypeReference<List<ActorsFilms>>() {
				});

		String format = outputConverter.getFormat();
		String template = """
				Generate the filmography of 5 movies for Tom Hanks and Bill Murray.
				{format}
				""";
		PromptTemplate promptTemplate = new PromptTemplate(template);
		promptTemplate.add("format", format);
		Prompt prompt = new Prompt(promptTemplate.createMessage());

		Generation generation = chatModel.call(prompt).getResult();

		List<ActorsFilms> actorsFilmsList = outputConverter.convert(generation.getOutput().getText());
		return actorsFilmsList;
	}

	/*
	 * This method demonstrates how to convert the response into 
	 * into Map.
	 */
	public Map<String, Object> response_map() {
		Map<String, Object> result = chatClient.prompt()
				.user(u -> u.text("Provide me a List of {subject}").param("subject",
						"an array of numbers from 1 to 9 under they key name 'numbers'"))
				.call().entity(new ParameterizedTypeReference<Map<String, Object>>() {
				});

		return result;

	}

	/*
	 * This method demonstrates how to convert the response into 
	 * into List.
	 */
	public List<String> response_list() {
		List<String> flavors = chatClient.prompt()
				.user(u -> u.text("List five {subject}").param("subject", "ice cream flavors")).call()
				.entity(new ListOutputConverter(new DefaultConversionService()));
		return flavors;

	}

	/*
	 * This method demonstrates how to convert the response into 
	 * into List using ListOutputConverter directly without using the entity() method.
	 */
	public List<String> response_list_basic() {
		ListOutputConverter listOutputConverter = new ListOutputConverter(new DefaultConversionService());

		String format = listOutputConverter.getFormat();
		System.out.println("ListOutputConverter format: " + format);
		String template = "List five {subject}  {format}";
		PromptTemplate promptTemplate = new PromptTemplate(template);
		promptTemplate.add("subject", "ice cream flavours");
		promptTemplate.add("format",format);
		Prompt prompt = new Prompt(promptTemplate.createMessage());

		Generation generation = chatModel.call(prompt).getResult();

		return listOutputConverter.convert(generation.getOutput().getText());

	}

	/*
	 * This method demonstrates how to convert the response into 
	 * structured json text format which is defined by the MathReasoning class structure
	 */
	public MathReasoning response_json_basic() {
		// Create a BeanOutputConverter for MathReasoning and get the required format
		BeanOutputConverter<MathReasoning> outputConverter = new BeanOutputConverter<>(MathReasoning.class);
		String format = outputConverter.getFormat();

		// Build a prompt with the format (JSON schema) included
		String template = "Solve the equation 8x + 7 = -23 and explain the steps. {format}";
		PromptTemplate promptTemplate = new PromptTemplate(template);
		promptTemplate.add("format", format);
		Prompt prompt = new Prompt(promptTemplate.createMessage());

		// Call the model and get the result
		Generation generation = chatModel.call(prompt).getResult();

		// Convert the output to MathReasoning using the BeanOutputConverter
		return outputConverter.convert(generation.getOutput().getText());
	}

	/**
	 * This method demonstrates what is inside the response generation
	 * Observe the metadata and usage information and Generation class output.
	 * @return
	 */
	public String response_generation_demo() {
		String promptText =
				  "Give me 5 quotes from famous people about technology."; Prompt prompt = new
				  Prompt(promptText); ChatResponse chatResponse = chatModel.call(prompt);
				  
				  List<Generation> generations = chatResponse.getResults(); for (Generation
				  generation : generations) {
				  System.out.println(generation.getOutput().getText()); }
				  
				  ChatResponseMetadata metadata= chatResponse.getMetadata();
				  System.out.println("Metadata: " + metadata); System.out.println("Usage: " +
				  metadata.getUsage()); System.out.println("Model: " + metadata.getModel());
				  return chatResponse.getResults().toString();
	}

	 
}