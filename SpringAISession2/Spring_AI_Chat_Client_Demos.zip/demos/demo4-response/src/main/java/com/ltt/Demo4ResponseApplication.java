package com.ltt;

import org.springframework.ai.azure.openai.AzureOpenAiChatModel;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class Demo4ResponseApplication {

	public static void main(String[] args) {
		SpringApplication.run(Demo4ResponseApplication.class, args);
	}
	
	@Bean
    public ChatClient openAIChatClient(AzureOpenAiChatModel chatModel) {
        return ChatClient.create(chatModel);
    }

}
