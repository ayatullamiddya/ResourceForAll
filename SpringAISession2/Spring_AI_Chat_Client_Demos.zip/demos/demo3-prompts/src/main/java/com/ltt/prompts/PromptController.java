package com.ltt.prompts;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PromptController {
	@Autowired
	public PromptsService service;


	@GetMapping("/promptex1")
	public String prompt_shots() {
		String output = "0 shot:" + service.prompt_zero_shot() + "\n\n" +
				"1 shot: " + service.prompt_one_shot_few_shots() + "\n\n" +
				"Chain of thought zero shot: " + service.prompt_chain_of_thought_zero_shot();
		return output;

	}

	@GetMapping("/promptex2")
	public String prompt_system_user() {
		String output = "System Prompting: " + service.prompt_system_prompting() + "\n\n" +
				"Role Prompting: " + service.prompt_role_prompting() + "\n\n" +
				"User Prompting: " + service.prompt_user_prompting()+"\n\n" +
				"Prompt from File: " + service.prompt_fromfile_dynamic() ;
		return output;
	}
	
	@GetMapping("/promptex3")
	public String prompt_templates() {
		String output = "Prompt Templates: " + service.prompt_templates() + "\n\n" +
				"Contextual Prompting: " + service.prompt_contextual_prompting() + "\n\n" +
				"Custom Prompt Template Delimiter: " + service.prompt_custom_promptTemplateDelimiter() + "\n\n" +
				"Assistant Message: " + service.prompt_assistantMessage();
		System.out.println("Output: " + output);
	return output;
	}
	
	@GetMapping("/promptex4")
	public String prompt_code() {
		String output = "Prompting Writing Code: " + service.prompt_code_prompting_writing_code() + "\n\n" +
				"Prompting Explaining Code: " + service.prompt_code_prompting_explaining_code();
		return output;
	}
	
	@GetMapping("/chatoptions")
	public String chat_optionsdemo() {
		String output = "Chat Options: " + service.chat_options_demo();
		return output;
	}
	
}
