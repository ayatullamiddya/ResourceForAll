package com.ltt.prompts;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.prompt.AssistantPromptTemplate;
import org.springframework.ai.chat.prompt.ChatOptions;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.chat.prompt.PromptTemplate;
import org.springframework.ai.chat.prompt.SystemPromptTemplate;
import org.springframework.ai.template.TemplateRenderer;
import org.springframework.ai.template.st.StTemplateRenderer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import com.ltt.prompts.MovieReviews.Sentiment;

@Service
public class PromptsService {
	
	@Autowired
	public ChatClient chatClient;

	@Value("classpath:assist-file.st")
	private Resource file;

	// zero-shot prompting by providing a single instruction without examples or context.
	public String prompt_zero_shot( ) {
		   String response = chatClient.prompt("Create a nursery rhyme for kids about a cat in 4-5 sentences.")
			        .call()
			        .content();
			   
		System.out.println("Output: " + response);
		return response;
	}

	
	public String prompt_one_shot_few_shots( ) {
		String response = chatClient.prompt("""
		        Create a nursery rhyme for kids about a cat in 4-5 sentences.

		        EXAMPLE:
		        Cat! Cat! Where are you?
		        cat! Cat! I want to play with you.
		        Meow! Meow! I am here,
		        Feed me a fish to make me cheer!
		        

		        Now, create a nursery rhyme for kids about a dog in 4-5 sentences similar to the example above.
		        """)
		    .call()
		    .content();

		    System.out.println("Output: " + response);
		    return response;
	}


	public String prompt_chain_of_thought_zero_shot( ) {
		String output = chatClient.prompt("""
				When I was 3 years old, my partner was 3 times my age. Now,
				I am 20 years old. How old is my partner?

				Let's think step by step.
				""").call().content();
		System.out.println(output);
		return output;
	}
	
	//system() & user() prompt and chat options
	public String prompt_system_prompting( ) {
		String movieReview = chatClient.prompt()
				.system("Classify movie reviews as positive, neutral or negative. Only return the label in uppercase.")
				.user("""							
				Review: "Most of all, Finding Nemo is a touching tale which reassures you
				that even though things may look bleak,
				it will all turn out well in the end..
				I wish there were more movies like this masterpiece.

						Sentiment:
						""")
				.options(ChatOptions.builder().model("gpt-4o").temperature(0.1).topP(0.8).maxTokens(5).build())
				.call().content();
		System.out.println(movieReview);
		return movieReview;
	}


	//role prompting via user() 
	public String prompt_role_prompting( ) {
		String travelSuggestions = chatClient.prompt()
				.system("""
				Act as a travel guide.User will write to you
				about his location and you will suggest only 3 places to visit nearby.
				""")
				.user("""
				My suggestion: "I am in Chennai and I want to visit only 5 temples."
				Travel Suggestions:
				""").call().content();
		System.out.println(travelSuggestions);
		return travelSuggestions;
	}

	
	public String prompt_user_prompting( ) {
		String userText = """
				Tell me about 2 famous book and and write their small summary.
				Write at least two sentence for each book.
				""";

		Message userMessage = new UserMessage(userText);

		//with system context
		String bookline = chatClient.prompt(new Prompt(userMessage)).call().content();
		System.out.println(bookline);

		String systemText = """
				You are a helpful AI assistant that helps people find information.
				Your name is Rajesh
				You should reply to the user's request with your name and a greeting.
				  """;

		Message systemMessage = new SystemPromptTemplate(systemText).createMessage();

		Prompt prompt = new Prompt(List.of(userMessage, systemMessage));

		bookline = chatClient.prompt(prompt).call().content();
		System.out.println(bookline);
		return bookline;
	}
	
	
	//code prompting via prompt()
	public String prompt_code_prompting_writing_code( ) {
		String javaCode = chatClient
				.prompt("""
						Write a code snippet in Java, which creates a Spring AI REST controller class that calls Gemini AI using ChatClient.
						""")
				.options(ChatOptions.builder().temperature(0.1) // Low temperature for deterministic code
						.build())
				.call().content();
		System.out.println(javaCode);
		return javaCode;
	}
	
	
	// PromptTemplates using user() and {} delimiter
	public String prompt_code_prompting_explaining_code( ) {
		String code = """
				#!/bin/bash
				echo "Enter the folder name: "
				read folder_name
				if [ ! -d "$folder_name" ]; then
				echo "Folder does not exist."
				exit 1
				fi
				files=( "$folder_name"/* )
				for file in "${files[@]}"; do
				new_file_name="draft_$(basename "$file")"
				mv "$file" "$new_file_name"
				done
				echo "Files renamed successfully."
				""";

		String explanation = chatClient.prompt()
				.user(u -> u.text("""
				Explain to me the below Bash code:
				```
				{code}
				```
				""").param("code", code)).call().content();
		System.out.println(explanation);
		return explanation;
	}
	
		

	//PromptTemplates
	public String prompt_contextual_prompting( ) {
		String articleSuggestions = chatClient.prompt().user(u -> u.text("""
				Suggest top 3 frameowrks to learn in Java and write an post with 4-5 lines of
				on why a developer should learn this.

				Context: {context}
				""").param("context", "You are writing for a post on a Javascript forum.")).call().content();

		System.out.println(articleSuggestions);
		return articleSuggestions;
	}


	public String prompt_templates( ) {
		String template = "The user is from {country} and wants movie recommendation "
				+ "on {genre} of movies. Suggest top 3 movies for this user";

		// Create a map of variables to fill the template
		Map<String, Object> variables = new HashMap<>();
		variables.put("country", "India");
		variables.put("genre", "comedy");
		
		PromptTemplate promptTemplate = new PromptTemplate(template);
		Prompt prompt = promptTemplate.create(variables);

		String output = chatClient.prompt(prompt).call().content();
		return output;
	}


	public String prompt_assistantMessage( ) {

		String userText = "Me and my friend went to the store.";

		Message userMessage = new UserMessage("Is this sentence correct: " + userText);

		String systemText = """
				You are a helpful AI assistant that .
				Your name is Rajesh
				You should reply to the user's request with your name and a greeting.
				""";

		Message systemMessage = new SystemPromptTemplate(systemText).createMessage();

		String instructions = """
				You are a helpful AI assistant that helps correct grammar mistakes.
				You should provide feedback for the sentence: {text}
				and correct if there are any issues.
				""";

		AssistantPromptTemplate assistantPromptTemplate = new AssistantPromptTemplate(instructions);

		Message assistantPromptTemplateMessage = assistantPromptTemplate.createMessage(Map.of("text", userText));

		Prompt prompt = new Prompt(List.of(userMessage, systemMessage, assistantPromptTemplateMessage));

		String response = chatClient.prompt(prompt).call().content();
		System.out.println(response);
		return response;
	}
	
	public String prompt_custom_promptTemplateDelimiter( ) {
	
		PromptTemplate promptTemplate = PromptTemplate.builder()
			    .renderer(StTemplateRenderer.builder().startDelimiterToken('<').endDelimiterToken('>').build())
			    .template("""
			            Tell me the names of 5 movies whose director was <director>.
			            """)
			    .build();

			String prompt = promptTemplate.render(Map.of("director", "Michael Bay"));
			String response = chatClient.prompt(prompt).call().content();
			System.out.println(response);
			return response;
	}

	public String prompt_fromfile_dynamic( ) {

		String userText = """
				 Tell me about 2 famous books and a write a small summary on them.
				  Write at least a sentence for each book.
				""";

		UserMessage userMessage = new UserMessage(userText);

		SystemPromptTemplate systemPromptTemplate = new SystemPromptTemplate(file);
		Message systemMessage = systemPromptTemplate.createMessage(Map.of("name", "AI Chat Bot"));

		Prompt prompt = new Prompt(List.of(userMessage, systemMessage));

		return chatClient.prompt(prompt).call().content();
	}


	public String chat_options_demo() {
		String response1 = chatClient.prompt()
	        .user("Create a small story based on the nursery rhyme called Ring around the rosies..")
	        .options(ChatOptions.builder()
	            .temperature(0.7)
	            .topP(0.9)
	            .maxTokens(200)
	            .frequencyPenalty(0.5)
	            .stopSequences(List.of("stop", "We all fall down"))	       
	            .presencePenalty(0.5)
	            .model("gpt-4o")
	            .build())
	        .call()
	        .content();
	    System.out.println(response1);
	    
		String response2= chatClient.prompt()
		        .user("Create a small story based on the nursery rhyme called Ring around the rosies..")
		        .options(ChatOptions.builder()
		            .temperature(0.1)
		            .topP(0.2)
		            .maxTokens(80)
		            .frequencyPenalty(0.9)
		            .stopSequences(List.of("Fall down", "We all fall down"))
		            .presencePenalty(0.1)
		            .model("gpt-4o")
		            .build())
		        .call()
		        .content();
		System.out.println("\n\n New Story " +response2);
	    return response1;
	}
	

}