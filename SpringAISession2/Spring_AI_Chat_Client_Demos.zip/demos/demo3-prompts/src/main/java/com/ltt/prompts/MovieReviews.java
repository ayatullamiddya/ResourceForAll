package com.ltt.prompts;

record MovieReviews(Movie[] movie_reviews) {
	enum Sentiment {
		POSITIVE, NEUTRAL, NEGATIVE
	}

	record Movie(Sentiment sentiment, String name) {
	}
}