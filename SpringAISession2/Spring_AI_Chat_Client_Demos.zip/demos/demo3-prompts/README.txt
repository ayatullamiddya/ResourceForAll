This demo demonstrates how to create and use prompts , prompt templates and 
tune the chat options parameters to control the response from LLM.

See endpoints exposed in PromptController.java and see prompts used in class PromptService.java.


Different types of prompts are:
1)zero shot prompt-
   - A prompt that does not provide any examples or context.
2)one shot prompt-
   - A prompt that provides a single example or context to guide the model's response.
3)few shot prompt-
   - A prompt that provides multiple examples or contexts to guide the model's response.
4)chain of thought prompt-
   - A prompt that encourages the model to think step-by-step or reason through a problem before providing an answer.
5)prompt template-
   - A reusable template that can be filled with specific values or variables to create a prompt dynamically.
6) custom prompt-
   - A user-defined prompt that can be tailored to specific needs or use cases.
 7)Code generation prompt-
   - A prompt specifically designed to generate code or programming-related content. 
   
In class PromptService.java,  observe usage of chatclient fluent api methods like-
prompt():	Starts building a new chat prompt request.
call(): 		Executes the chat request and returns the response.
options(): 	Sets additional configuration options for the chat request.
stream(): 	Initiates streaming of chat responses.
user(): 		Adds a user message to the chat prompt.
system(): 	Adds a system message/context/rule to the chat prompt.
param(): 	Sets a custom parameter for the chat request.
content(): 	returns the main text content from the chat response.
mutate(): The mutate() method allows you to dynamically modify the client configuration, 
such as setting a custom base URL, headers, or other properties



Dependencies
 -----------------------
 In pom.xml see below dependencies
 
 <dependency>
			<groupId>org.springframework.ai</groupId>
			<artifactId>spring-ai-starter-model-azure-openai</artifactId>
		</dependency>			
	
	
	
In application.properties
-------------------------------------------

IMPORTANT: Please replace the properties below with your own LLM provider details.

See below properties for Azure Open AI

		# API key for authentication with the chat model provider . Add to environment variables in run config
		spring.ai.azure.openai.api-key=${AZURE_API_KEY}
		# Endpoint URL for the chat model's API
		spring.ai.azure.openai.endpoint=https://java-ai-resgrp.openai.azure.com/
		#deployment model or chat model name
		spring.ai.azure.openai.chat.options.model=gpt-4o
	
Replace with Vertex AI Gemini properties below if needed

spring.ai.vertex.ai.gemini.project-id=${PROJECT_ID}
spring.ai.vertex.ai.gemini.location=us-central1
spring.ai.openai.chat.base-url=https://generativelanguage.googleapis.com
spring.ai.openai.chat.completions-path=/v1beta/openai/chat/completions
spring.ai.openai.api-key=${GEMINI_API_KEY}
spring.ai.openai.chat.options.model=gemini-2.0-flash-001

Right click on project->Run->Run Configurations->Environment Variables and set the AZURE_API_KEY variable to your Azure OpenAI API key.


		 